// Copyright 1998-2019 Epic Games, Inc. All Rights Reserved.

#include "FIT3094_A1_Code.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, FIT3094_A1_Code, "FIT3094_A1_Code" );
