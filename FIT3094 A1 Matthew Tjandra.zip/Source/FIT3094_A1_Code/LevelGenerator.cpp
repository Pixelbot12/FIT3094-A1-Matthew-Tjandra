// Fill out your copyright notice in the Description page of Project Settings.


#include "LevelGenerator.h"

#include "Engine/World.h"
#include <Runtime\Core\Public\Containers\Queue.h>

// Sets default values
ALevelGenerator::ALevelGenerator()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	
}

// Called when the game starts or when spawned
void ALevelGenerator::BeginPlay()
{
	Super::BeginPlay();
}

// Called every frame
void ALevelGenerator::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

void ALevelGenerator::GenerateWorldFromFile(TArray<FString> WorldArrayStrings)
{
	// If empty array exit immediately something is horribly wrong
	if(WorldArrayStrings.Num() == 0)
	{
		UE_LOG(LogTemp, Warning, TEXT("World Array is empty!"));
		return;
	}

	// Second line is Height (aka X value)
	FString Height = WorldArrayStrings[1];
	Height.RemoveFromStart("height ");
	MapSizeX = FCString::Atoi(*Height);
	UE_LOG(LogTemp, Warning, TEXT("Height: %d"), MapSizeX);

	// Third line is Width (aka Y value)
	FString Width = WorldArrayStrings[2];
	Width.RemoveFromStart("width ");
	MapSizeY = FCString::Atoi(*Width);
	UE_LOG(LogTemp, Warning, TEXT("Width: %d"), MapSizeY);
	
	// After removing top 4 lines this is the map itself so iterate each line
	for (int LineNum = 4; LineNum < WorldArrayStrings.Num(); LineNum++)
	{
		for (int CharNum = 0; CharNum < WorldArrayStrings[LineNum].Len(); CharNum++)
		{
			CharMapArray[LineNum-4][CharNum] = WorldArrayStrings[LineNum][CharNum];
		}
	}

	GenerateNodeGrid();
	SpawnWorldActors();
}

void ALevelGenerator::SpawnWorldActors()
{
	UWorld* World = GetWorld();

	// Make sure that all blueprints are connected. If not then fail
	if(WallBlueprint && OpenBlueprint && WaterBlueprint && SwampBlueprint && TreeBlueprint)
	{
		// For each grid space spawn an actor of the correct type in the game world
		for(int x = 0; x < MapSizeX; x++)
		{
			for (int y = 0; y < MapSizeY; y++)
			{
				float XPos = x * GRID_SIZE_WORLD;
				float YPos = y * GRID_SIZE_WORLD;

				FVector Position(XPos, YPos, 0);

				switch (CharMapArray[x][y])
				{
					case '.':
					case 'G':
						World->SpawnActor(OpenBlueprint, &Position, &FRotator::ZeroRotator);
						break;
					case '@':
					case 'O':
						World->SpawnActor(WallBlueprint, &Position, &FRotator::ZeroRotator);
						break;
					case 'T':
						World->SpawnActor(TreeBlueprint, &Position, &FRotator::ZeroRotator);
						break;
					case 'S':
						World->SpawnActor(SwampBlueprint, &Position, &FRotator::ZeroRotator);
						break;
					case 'W':
						World->SpawnActor(WaterBlueprint, &Position, &FRotator::ZeroRotator);
						break;
					default:
						break;
				}
			}
		}
	}

	// Generate Initial Agent Type 1 Positions
	if(AgentBlueprint)
	{
		for (int i = 0; i < NUM_AGENTS; i++)
		{
			int RandXPos = 0;
			int RandYPos = 0;
			bool isFree = false;

			while (!isFree) {
				RandXPos = FMath::RandRange(0, MapSizeX - 1);
				RandYPos = FMath::RandRange(0, MapSizeY - 1);

				if (WorldArray[RandXPos][RandYPos]->GridType == GridNode::Open && WorldArray[RandXPos][RandYPos]->ObjectAtLocation == nullptr)
				{
					isFree = true;
				}
			}

			FVector Position(RandXPos * GRID_SIZE_WORLD, RandYPos * GRID_SIZE_WORLD, 20);
			AAgent* Agent = World->SpawnActor<AAgent>(AgentBlueprint, Position, FRotator::ZeroRotator);
			//Pass level generator to Agent
			Agent->levelGen = this;

			WorldArray[RandXPos][RandYPos]->ObjectAtLocation = Agent;
		}
	}

	// Generate Initial Agent Type 2 Positions
	if (Agent2Blueprint)
	{
		for (int i = 0; i < NUM_AGENTS; i++)
		{
			int RandXPos = 0;
			int RandYPos = 0;
			bool isFree = false;

			while (!isFree) {
				RandXPos = FMath::RandRange(0, MapSizeX - 1);
				RandYPos = FMath::RandRange(0, MapSizeY - 1);

				if (WorldArray[RandXPos][RandYPos]->GridType == GridNode::Open && WorldArray[RandXPos][RandYPos]->ObjectAtLocation == nullptr)
				{
					isFree = true;
				}
			}

			FVector Position(RandXPos * GRID_SIZE_WORLD, RandYPos * GRID_SIZE_WORLD, 20);
			AAgent* Agent = World->SpawnActor<AAgent>(Agent2Blueprint, Position, FRotator::ZeroRotator);
			//Pass level generator to Agent
			Agent->levelGen = this;

			WorldArray[RandXPos][RandYPos]->ObjectAtLocation = Agent;
		}
	}

	// Generate Initial Food Type 1 Positions
	if(FoodBlueprint)
	{
		for(int i = 0; i < NUM_FOOD; i++)
		{
			int RandXPos = 0;
			int RandYPos = 0;
			bool isFree = false;

			while (!isFree) {
				RandXPos = FMath::RandRange(0, MapSizeX - 1);
				RandYPos = FMath::RandRange(0, MapSizeY - 1);

				if (WorldArray[RandXPos][RandYPos]->GridType == GridNode::Open && WorldArray[RandXPos][RandYPos]->ObjectAtLocation == nullptr)
				{
					isFree = true;
				}
			}

			FVector Position(RandXPos * GRID_SIZE_WORLD, RandYPos * GRID_SIZE_WORLD, 20);
			AFood* NewFood = World->SpawnActor<AFood>(FoodBlueprint, Position, FRotator::ZeroRotator);

			WorldArray[RandXPos][RandYPos]->ObjectAtLocation = NewFood;
			NewFood->CurrentNode = WorldArray[RandXPos][RandYPos];
			FoodActors.Add(NewFood);
		}
	}

	// Generate Initial Food Type 2 Positions
	if (Food2Blueprint)
	{
		for (int i = 0; i < NUM_FOOD; i++)
		{
			int RandXPos = 0;
			int RandYPos = 0;
			bool isFree = false;

			while (!isFree) {
				RandXPos = FMath::RandRange(0, MapSizeX - 1);
				RandYPos = FMath::RandRange(0, MapSizeY - 1);

				if (WorldArray[RandXPos][RandYPos]->GridType == GridNode::Open && WorldArray[RandXPos][RandYPos]->ObjectAtLocation == nullptr)
				{
					isFree = true;
				}
			}

			FVector Position(RandXPos * GRID_SIZE_WORLD, RandYPos * GRID_SIZE_WORLD, 20);
			AFood* NewFood = World->SpawnActor<AFood>(Food2Blueprint, Position, FRotator::ZeroRotator);

			WorldArray[RandXPos][RandYPos]->ObjectAtLocation = NewFood;
			NewFood->CurrentNode = WorldArray[RandXPos][RandYPos];
			FoodActors.Add(NewFood);
		}
	}
}

// Generates the grid of nodes used for pathfinding and also for placement of objects in the game world
void ALevelGenerator::GenerateNodeGrid()
{
	for(int X = 0; X < MapSizeX; X++)
	{
		for(int Y = 0; Y < MapSizeY; Y++)
		{
			WorldArray[X][Y] = new GridNode();
			WorldArray[X][Y]->X = X;
			WorldArray[X][Y]->Y = Y;

			// Characters as defined from the map file
			switch(CharMapArray[X][Y])
			{
				case '.':
				case 'G':
					WorldArray[X][Y]->GridType = GridNode::Open;
					break;
				case '@':
				case 'O':
					WorldArray[X][Y]->GridType = GridNode::Wall;
					break;
				case 'T':
					WorldArray[X][Y]->GridType = GridNode::Forest;
					break;
				case 'S':
					WorldArray[X][Y]->GridType = GridNode::Swamp;
					break;
				case 'W':
					WorldArray[X][Y]->GridType = GridNode::Water;
					break;
			}
		}
	}
}

// Reset all node values (F, G, H & Parent)
void ALevelGenerator::ResetAllNodes()
{
	for (int X = 0; X < MapSizeX; X++)
	{
		for (int Y = 0; Y < MapSizeY; Y++)
		{
			WorldArray[X][Y]->F = 0;
			WorldArray[X][Y]->G = 0;
			WorldArray[X][Y]->H = 0;
			WorldArray[X][Y]->Parent = nullptr;
		}
	}
}

float ALevelGenerator::CalculateDistanceBetween(GridNode* first, GridNode* second)
{
	FVector distToTarget = FVector(second->X - first->X,second->Y - first->Y, 0);
	return distToTarget.Size();
}

void ALevelGenerator::CalculateAStar(GridNode* startNode, AAgent* currentAgent)
{
	//Clear all nodes
	ResetAllNodes();

	//Get passed start node and calculating agent
	GridNode* StartNode = startNode;
	AAgent* CurrentAgent = currentAgent;

	float tempDistance = NULL;
	float shortestDistance = NULL;
	int closestFood = NULL;

	// Spawn more food if there are not the right number, in prep for checking foods
	ReplenishFood();

	//Check foods and select closest one
	for (int i = 0; i < FoodActors.Num(); i++)
	{
		//if agent is type 1, check for food type 1
		if (CurrentAgent->AgentType == 1 && FoodActors[i]->FoodType == 1)
		{
			int foodX = FoodActors[i]->GetActorLocation().X / GRID_SIZE_WORLD;
			int foodY = FoodActors[i]->GetActorLocation().Y / GRID_SIZE_WORLD;
			GridNode* tempFood = WorldArray[foodX][foodY];

			tempDistance = CalculateDistanceBetween(StartNode, tempFood);

			if (tempDistance < shortestDistance || shortestDistance == NULL)
			{
				shortestDistance = tempDistance;
				closestFood = i;
			}
		}

		//if agent is type 2, check for food type 2
		else if (CurrentAgent->AgentType == 2 && FoodActors[i]->FoodType == 2)
		{
			int foodX = FoodActors[i]->GetActorLocation().X / GRID_SIZE_WORLD;
			int foodY = FoodActors[i]->GetActorLocation().Y / GRID_SIZE_WORLD;
			GridNode* tempFood = WorldArray[foodX][foodY];

			tempDistance = CalculateDistanceBetween(StartNode, tempFood);

			if (tempDistance < shortestDistance || shortestDistance == NULL)
			{
				shortestDistance = tempDistance;
				closestFood = i;
			}
		}
	}

	//Set closest food node as goal node
	int goalX = FoodActors[closestFood]->GetActorLocation().X / GRID_SIZE_WORLD;
	int goalY = FoodActors[closestFood]->GetActorLocation().Y / GRID_SIZE_WORLD;
	GridNode* GoalNode = WorldArray[goalX][goalY];
	CurrentAgent->TargetFoodNode = GoalNode;

	GridNode* CurrentNode = nullptr;
	GridNode* TempNode = nullptr;
	bool IsGoalFound = false;

	TArray<GridNode*> OpenList;
	TArray<GridNode*> ClosedList;

	StartNode->G = 0;
	StartNode->H = CalculateDistanceBetween(StartNode, GoalNode);
	StartNode->F = StartNode->G + StartNode->H;

	OpenList.Add(StartNode);

	while (OpenList.Num() > 0)
	{

		//Search openList for lowest fitness
		float lowestF = 1000000000;
		for (int i = 0; i < OpenList.Num(); i++)
		{
			if (OpenList[i]->F < lowestF)
			{
				lowestF = OpenList[i]->F;
				CurrentNode = OpenList[i];
			}
		}

		OpenList.Remove(CurrentNode);
		//Add to closedList
		ClosedList.Add(CurrentNode);

		//Check if node is goal node
		if (CurrentNode == GoalNode)
		{
			IsGoalFound = true;
			break;
		}

		//Left
		if (CurrentNode->Y - 1 >= 0)
		{
			TempNode = WorldArray[CurrentNode->X][CurrentNode->Y - 1];

			//Determine whether to consider the node, need to check object at location for type
			if (!ClosedList.Contains(TempNode) && TempNode->GridType != GridNode::Wall && (TempNode->ObjectAtLocation == nullptr || TempNode->ObjectAtLocation == GoalNode->ObjectAtLocation))
			{
				int PossibleG = CurrentNode->G + TempNode->GetTravelCost();
				bool IsPossibleGBetter = false;

				if (!OpenList.Contains(TempNode))
				{ 
					OpenList.Add(TempNode);
					TempNode->H = CalculateDistanceBetween(TempNode, GoalNode);
					IsPossibleGBetter = true;
				}
				else if (PossibleG < TempNode->G)
				{
					IsPossibleGBetter = true;
				}

				if (IsPossibleGBetter)
				{
					TempNode->Parent = CurrentNode;
					TempNode->G = PossibleG;
					TempNode->F = TempNode->G + TempNode->H;
				}
			}
		}

		//Top
		if (CurrentNode->X + 1 < MapSizeX)
		{
			TempNode = WorldArray[CurrentNode->X + 1][CurrentNode->Y];

			if (!ClosedList.Contains(TempNode) && TempNode->GridType != GridNode::Wall && (TempNode->ObjectAtLocation == nullptr || TempNode->ObjectAtLocation == GoalNode->ObjectAtLocation))
			{
				int PossibleG = CurrentNode->G + TempNode->GetTravelCost();
				bool IsPossibleGBetter = false;

				if (!OpenList.Contains(TempNode))
				{
					OpenList.Add(TempNode);
					TempNode->H = CalculateDistanceBetween(TempNode, GoalNode);
					IsPossibleGBetter = true;
				}
				else if (PossibleG < TempNode->G)
				{
					IsPossibleGBetter = true;
				}

				if (IsPossibleGBetter)
				{
					TempNode->Parent = CurrentNode;
					TempNode->G = PossibleG;
					TempNode->F = TempNode->G + TempNode->H;
				}
			}
		}

		//Right
		if (CurrentNode->Y + 1 < MapSizeY)
		{
			TempNode = WorldArray[CurrentNode->X][CurrentNode->Y + 1];

			if (!ClosedList.Contains(TempNode) && TempNode->GridType != GridNode::Wall && (TempNode->ObjectAtLocation == nullptr || TempNode->ObjectAtLocation == GoalNode->ObjectAtLocation))
			{
				int PossibleG = CurrentNode->G + TempNode->GetTravelCost();
				bool IsPossibleGBetter = false;

				if (!OpenList.Contains(TempNode))
				{
					OpenList.Add(TempNode);
					TempNode->H = CalculateDistanceBetween(TempNode, GoalNode);
					IsPossibleGBetter = true;
				}
				else if (PossibleG < TempNode->G)
				{
					IsPossibleGBetter = true;
				}

				if (IsPossibleGBetter)
				{
					TempNode->Parent = CurrentNode;
					TempNode->G = PossibleG;
					TempNode->F = TempNode->G + TempNode->H;
				}
			}
		}

		//Bottom
		if (CurrentNode->X - 1 >= 0)
		{
			TempNode = WorldArray[CurrentNode->X - 1][CurrentNode->Y];

			if (!ClosedList.Contains(TempNode) && TempNode->GridType != GridNode::Wall && (TempNode->ObjectAtLocation == nullptr || TempNode->ObjectAtLocation == GoalNode->ObjectAtLocation))
			{
				int PossibleG = CurrentNode->G + TempNode->GetTravelCost();
				bool IsPossibleGBetter = false;

				if (!OpenList.Contains(TempNode))
				{
					OpenList.Add(TempNode);
					TempNode->H = CalculateDistanceBetween(TempNode, GoalNode);
					IsPossibleGBetter = true;
				}
				else if (PossibleG < TempNode->G)
				{
					IsPossibleGBetter = true;
				}

				if (IsPossibleGBetter)
				{
					TempNode->Parent = CurrentNode;
					TempNode->G = PossibleG;
					TempNode->F = TempNode->G + TempNode->H;
				}
			}
		}
	}

	//If goal is found, store path in the current agent
	if (IsGoalFound)
	{
		CurrentAgent->Path.Empty();
		CurrentNode = GoalNode;

		while (CurrentNode->Parent != nullptr)
		{
			CurrentAgent->Path.Insert(CurrentNode, 0);
			CurrentNode = CurrentNode->Parent;
		}	
	}
}

void ALevelGenerator::ReplenishFood()
{
	//Check all foods, if food is eaten move to open node
	for (int i = 0; i < FoodActors.Num(); i++)
	{
		if (FoodActors[i]->IsEaten == true)
		{
			FoodActors[i]->IsEaten = false;
			
			int RandXPos = 0;
			int RandYPos = 0;
			bool isFree = false;

			while (!isFree) {
				RandXPos = FMath::RandRange(0, MapSizeX - 1);
				RandYPos = FMath::RandRange(0, MapSizeY - 1);

				if (WorldArray[RandXPos][RandYPos]->GridType == GridNode::Open && WorldArray[RandXPos][RandYPos]->ObjectAtLocation == nullptr)
				{
					isFree = true;
				}
			}

			FVector Position(RandXPos * GRID_SIZE_WORLD, RandYPos * GRID_SIZE_WORLD, 20);
			FoodActors[i]->SetActorLocation(Position);
			FoodActors[i]->CurrentNode = WorldArray[RandXPos][RandYPos];
			WorldArray[RandXPos][RandYPos]->ObjectAtLocation = FoodActors[i];
		}
	}
}
