// Fill out your copyright notice in the Description page of Project Settings.


#include "Agent.h"

#include "LevelGenerator.h"
#include "Food.h"

// Sets default values
AAgent::AAgent()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	Health = 50;
	MoveSpeed = 100;
	Tolerance = 20;
}

// Called when the game starts or when spawned
void AAgent::BeginPlay()
{
	Super::BeginPlay();

	// Set a timer for every two seconds and call the decrease health function
	GetWorldTimerManager().SetTimer(TimerHandle, this, &AAgent::DecreaseHealth, 2.0f, true, 2.0f);
}

void AAgent::DecreaseHealth()
{
	// Decrease health by one and if 0 then destroy object
	Health--;

	UE_LOG(LogTemp, Warning, TEXT("Health: %i"), Health);

	if(Health <= 0)
	{
		GetWorldTimerManager().ClearTimer(TimerHandle);
		//Remove Agent, clear its node
		ResetPath();
		CurrentNode->ObjectAtLocation = nullptr;
		Destroy();
	}
}

void AAgent::IncreaseHealth()
{
	Health = 50;
}

// Called every frame
void AAgent::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	//if there is no food target, get new one with path
	if (Path.Num() == 0)
	{
		//UE_LOG(LogTemp, Warning, TEXT("Call Runs"));
		int currentPositionX = GetActorLocation().X / ALevelGenerator::GRID_SIZE_WORLD;
		int currentPositionY = GetActorLocation().Y / ALevelGenerator::GRID_SIZE_WORLD;
		CurrentNode = levelGen->WorldArray[currentPositionX][currentPositionY];;

		//Calculate Path
		levelGen->CalculateAStar(CurrentNode, this);
		
		//Store target food for checks
		TargetFood = Cast<AFood>(TargetFoodNode->ObjectAtLocation);

		//initialize agent as not moving
		InMotion = false;
	}

	//check if current food target and its location is still valid
	if (CheckFoodIsValid(TargetFood) && TargetFood->IsEaten == false && TargetFood->CurrentNode == TargetFoodNode)
	{
		//if there is a path, run through it
		if (Path.Num() > 0)
		{
			//if next node is empty, set object at location to itself and try to move towards it
			if (Path[0]->ObjectAtLocation == nullptr )
			{ 
				//CurrentNode = Path[Path.Num() - 1];
				//CurrentNode->ObjectAtLocation = this;
				
				Path[0]->ObjectAtLocation = this;
				//mark agent as attempting to move
				InMotion = true;
			}

			//attempt to move towards set node and consume food if it is endNode
			else if (Path[0]->ObjectAtLocation == this)
			{
				FVector CurrentPosition = GetActorLocation();

				float TargetXPos = Path[0]->X * ALevelGenerator::GRID_SIZE_WORLD;
				float TargetYPos = Path[0]->Y * ALevelGenerator::GRID_SIZE_WORLD;

				FVector TargetPosition(TargetXPos, TargetYPos, CurrentPosition.Z);

				FVector Direction = TargetPosition - CurrentPosition;
				Direction.Normalize();

				CurrentPosition += Direction * MoveSpeed * DeltaTime;

				if (FVector::Dist(CurrentPosition, TargetPosition) <= Tolerance)
				{
					CurrentPosition = TargetPosition;

					//if node is reached, free up old node and make the reached node the current node
					CurrentNode->ObjectAtLocation = nullptr;
					CurrentNode = Path[0];
					Path.RemoveAt(0);

					//mark agent as having reached node
					InMotion = false;

					//if endNode, eat food
					if (Path.Num() == 0)
					{
						TargetFood->IsEaten = true;
						levelGen->ReplenishFood();
						TargetFood = nullptr;
						IncreaseHealth();
						UE_LOG(LogTemp, Warning, TEXT("Food Eaten"));
					}
					
				}

				SetActorLocation(CurrentPosition);
			}

			//if next node isn't empty or itself, check it
			else if (Path[0]->ObjectAtLocation != nullptr)
			{
				//if it's the target food, set object at location as itself and try to move towards it
				if (Path[0]->ObjectAtLocation == TargetFood)
				{
					UE_LOG(LogTemp, Warning, TEXT("Food found"));
					Path[0]->ObjectAtLocation = this;
					//mark agent as attempting to move
					InMotion = true;
				}

				//if it's not target food, recalculate (reset object at location if in motion)
				else
				{
					ResetPath();
				}
			}
		}
	}

	//if food is not valid, recalculate (reset object at location if in motion)
	else
	{
		ResetPath();
	}
}

bool AAgent::CheckFoodIsValid(AFood* possibleFood)
{
	return levelGen->FoodActors.Contains(possibleFood);
}

void AAgent::ResetPath()
{
	TargetFood = nullptr;
	TargetFoodNode = nullptr;
	//check if agent was trying to move (and thus has failed)
	if (InMotion == true)
	{
		//if so, free up the next node that agent was moving to
		Path[0]->ObjectAtLocation = nullptr;
	}
	Path.Empty();
	//jump back to current node
	FVector CurrentPosition = GetActorLocation();
	float ResetXPos = CurrentNode->X * ALevelGenerator::GRID_SIZE_WORLD;
	float ResetYPos = CurrentNode->Y * ALevelGenerator::GRID_SIZE_WORLD;
	FVector TargetPosition(ResetXPos, ResetYPos, CurrentPosition.Z);
	SetActorLocation(TargetPosition);
}



